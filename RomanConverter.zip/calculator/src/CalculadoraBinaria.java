public class CalculadoraBinaria {
    public void add(int i) {

    }
}
