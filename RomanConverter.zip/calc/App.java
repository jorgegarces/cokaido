public class App {
    
    public static void main(String[] arguments) {
        Calc calc = new Calc(0);
        if (arguments[0] == "add") 
        
        calc.add(1);
    }
}   