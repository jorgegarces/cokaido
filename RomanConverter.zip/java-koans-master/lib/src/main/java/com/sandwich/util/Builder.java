package com.sandwich.util;

public interface Builder<T> {

	T build();
	
}
